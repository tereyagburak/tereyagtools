import os
import time

os.system("cls")
print("Hoşgeldiniz!")

duvar = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes10\\themes\\defa10.deskthemepack"
scsaver = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes10\\themes\\acik10.deskthemepack"
masasimg = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes10\\themes\\win10.deskthemepack"
renk = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes10\\themes\\cicekler.deskthemepack"



print("1-Windows (Varsayılan)")
print("2-Windows (Açık)")
print("3-Windows 10")
print("4-Çiçekler")





selp = input("Seçiminizi yapın. Tema uygulanacaktır ama mevcut duvar kağıdını kaybedeceksiniz:  ")

if selp == "1":
    os.system(duvar)

if selp == "2":
    os.system(scsaver)

if selp == "3":
    os.system(masasimg)

if selp == "4":
    os.system(renk)




os.system ("cls")


kapat = input("Programı sonlandırmak için ||Enter|| tuşuna basın.")


