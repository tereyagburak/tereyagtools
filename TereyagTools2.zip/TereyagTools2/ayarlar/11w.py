import os
import time

os.system("cls")
print("Hoşgeldiniz!")

duvar = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\w11dark.deskthemepack"
scsaver = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\w11light.deskthemepack"
masasimg = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\gundogumu.deskthemepack"
renk = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\w11spotlight.deskthemepack"
sesler = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\isima.deskthemepack"
temalar = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\yakalananhareket.deskthemepack"
spot = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\akis.deskthemepack"
red = "%USERPROFILE%\\TereyagTools\\ozellestirme\\themes\\red11.deskthemepack"
red11dene = "0"


print("1-Windows (Koyu)")
print("2-Windows (Açık) (Varsayılan)")
print("3-Gün Doğumu")
print("4-Windows Spotlight (beta)")
print("5-Işıma")
print("6-Yakalanan Hareket")
print("7-Akış")
print("8-red11 (created by tereyagburak)")




selp = input("Seçiminizi yapın. Tema uygulanacaktır ama mevcut duvar kağıdını kaybedeceksiniz:  ")

if selp == "1":
    os.system(duvar)

if selp == "2":
    os.system(scsaver)

if selp == "3":
    os.system(masasimg)

if selp == "4":
    os.system(renk)

if selp == "5":
    os.system(sesler)

if selp == "6":
    os.system(temalar)

if selp == "7":
    os.system(spot)

if selp == "8":
    os.system(red)
    red11dene = "1"


os.system ("cls")

if red11dene == "1":
    print("red11 denediğiniz için teşekkürler! WinDynamicDesktop kullanıyorsanız windd.info/themes adresinden .ddw uzantılı temayı deneyebilirsiniz.")
    kapat = input("Programı sonlandırmak için ||Enter|| tuşuna basın.")


else:
    kapat = input("Programı sonlandırmak için ||Enter|| tuşuna basın.")
