import os

os.system("cls")


#Ayarların yolu.

darkwhite = "python %USERPROFILE%\\TereyagTools\\darkwhite.py"
w11 = "python %USERPROFILE%\\TereyagTools\\11w.py"
w10 = "python %USERPROFILE%\\tereyagtools\\TereyagTools\\w10.py"
oldper = "python %USERPROFILE%\\TereyagTools\\oldper.py"
rtexp = "%USERPROFILE%\\TereyagTools\\rtexp.bat"


#Kullanıcıya seçim yaoması için seçenekler sunulur.

print("|||   ---TereyagTools Program Başlatma merkezi V0.1   ---|||")

print("1-Aydınlık-Karanlık Mod Ayarları.")
print("2-Windows 10/11 Eski kişiselleştirme Menüsü. ")
print("3-Windows 10 Tema Merkezi.")
print("4-Windows 11 Tema Merkezi ve Aydınlık-Karanlık Mod Ayarları.")
print("5-explorer.exe' yi yeniden başlat.")


sel = input("Seçiminizi yapın:  ")

if sel == "1":
    os.system(darkwhite)

if sel == "2":
    os.system(oldper)

if sel == "3":
    os.system(w10)

if sel == "4":
    os.system(w11)

if sel == "5":
    os.system(rtexp)
    os.system("python %USERPROFILE%\\TereyagTools\\toollauncher.py")
