import os
import time

os.system("cls")
print("Hoşgeldiniz!")

duvar = "ozellestirme\\eka\\dk.lnk"
scsaver = "ozellestirme\\eka\\ek.lnk"
masasimg = "ozellestirme\\eka\\msimge.lnk"
renk = "ozellestirme\\eka\\renkler.lnk"
sesler = "ozellestirme\\eka\\sesler.lnk"
temalar = "ozellestirme\\eka\\temalar.lnk"



print("1-Duvar Kağıdı Değiştirme Menüsü.")
print("2-Ekran Koruyucu Menüsü.")
print("3-Masaüstüne Simge Ekleme Menüsü.")
print("4-Windows Renklerini Değiştirme Menüsü.")
print("5-Sesleri Değiştirme Menüsü.")
print("6-Temaları Ekle/Değiştir/Uygula.")




selp = input("Seçiminizi yapın, sizi doğrudan denetim masasındaki ilgili bölüme atacaktır:  ")

if selp == "1":
    os.system(duvar)

if selp == "2":
    os.system(scsaver)

if selp == "3":
    os.system(masasimg)

if selp == "4":
    os.system(renk)

if selp == "5":
    os.system(sesler)

if selp == "6":
    os.system(temalar)

os.system ("cls")

kapat = input("Programı Kapantmak İçin Enter Tuşuna Basın.")
