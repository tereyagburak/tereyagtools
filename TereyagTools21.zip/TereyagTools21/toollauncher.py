import os
import platform


def calistir(betik):
    """Belirtilen betiği çalıştırır."""
    pythonla = get_python_path()
    if pythonla is None:
        print("Hata: Python yorumlayıcısı bulunamadı. Lütfen python.org/downloads sitesinden indirin.")
        return
    os.system(f"{pythonla} {betik}")


def get_python_path():
    """Python yorumlayıcısının dosya yolunu döndürür."""
    pythonsurumu = platform.python_version()
    if pythonsurumu.startswith("3.12"):
        return "%USERPROFILE%\\AppData\\Local\\Programs\\Python\\Python312\\python.exe"
    elif pythonsurumu.startswith("3.11"):
        return "%USERPROFILE%\\AppData\\Local\\Programs\\Python\\Python311\\python.exe"
    else:
        print(f"Hata: Desteklenmeyen Python sürümü: {pythonsurumu}")
        return None


# Ayarların yolu.
darkwhite = "darkwhite.py"
w11 = "11w.py"
w10 = "w10.py"
oldper = "oldper.py"
rtexp = "rtexp.bat"


# Kullanıcıya seçim yapması için seçenekler sunulur.
print("|||   ---TereyagTools Program Başlatma merkezi V2.0   ---|||")

print("1. Aydınlık-Karanlık Mod Ayarları.")
print("2. Windows 10/11 Eski Kişiselleştirme Menüsü.")
print("3. Windows 10 Tema Merkezi. (Microsoft Kaynaklı Bozuk!)")
print("4. Windows 11 Tema Merkezi ve Aydınlık-Karanlık Mod Ayarları. (Microsoft Kaynaklı Bozuk!)")
print("5. explorer.exe'yi yeniden başlat.")
print("6. TereyagTools'u Kapat!")



while True:
    sel = input("Seçiminizi yapın: ")

    if sel == "1":
        calistir(darkwhite)

    if sel == "2":
        calistir(oldper)

    if sel == "3":
        calistir(w10)

    if sel == "4":
        calistir(w11)

    if sel == "5":
        os.system(rtexp)


    if sel == "6":
        exit("Bye...")
    

    else:
        print("Program Sonlandırıldı.")
        print("1. Aydınlık-Karanlık Mod Ayarları.")
        print("2. Windows 10/11 Eski Kişiselleştirme Menüsü.")
        print("3. Windows 10 Tema Merkezi.")
        print("4. Windows 11 Tema Merkezi ve Aydınlık-Karanlık Mod Ayarları.")
        print("5. explorer.exe'yi yeniden başlat.")

